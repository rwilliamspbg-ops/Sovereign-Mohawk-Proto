# Full Validation Retry Summary

| Command | Exit Code | Duration (s) |
| --- | ---: | ---: |
| 01_make_lint | 2 | 0 |
| 02_make_verify | 2 | 0 |
| 03_make_test_python_sdk | 0 | 6 |
| 04_make_forensics_rehearsal | 0 | 14 |
| 05_make_golden_path_e2e | 0 | 228 |

- Total commands: 5
- Failures: 2
